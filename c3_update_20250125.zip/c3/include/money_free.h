list2_free_value(p->debit, money_free_value);

