VAR_POINTER(list_item_child,begin)
VAR_POINTER(list_item_child,read_pos)
VAR_POINTER(list_item_child,write_pos)
VAR(size_t,size)
