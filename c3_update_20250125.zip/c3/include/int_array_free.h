if (p->a)
{
	free(p->a);
	p->a = NULL;
}

