VAR_POINTER(void,item)
VAR_POINTER(list_item,next)
VAR_POINTER(list_item,prev)
VAR_POINTER(list,child)
