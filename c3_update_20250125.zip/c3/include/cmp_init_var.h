PARAMETER_POINTER(const char,file_name1)
PARAMETER_POINTER(const char,file_name2)
