chars_read_pchar(p->s, s, 0, 0);

