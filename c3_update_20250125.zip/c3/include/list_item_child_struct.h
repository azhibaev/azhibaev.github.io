VAR_POINTER(list_item,item)
VAR_POINTER(list,parent)
VAR_POINTER(list,child)
