p->parent = parent;

