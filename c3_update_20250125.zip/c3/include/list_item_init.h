p->item = s;

