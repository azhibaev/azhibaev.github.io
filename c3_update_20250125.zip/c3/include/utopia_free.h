if (f)
{
	fclose(f);
}

