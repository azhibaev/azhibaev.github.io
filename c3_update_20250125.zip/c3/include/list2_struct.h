VAR_POINTER(item2,p)
VAR_POINTER(item2,pf)
VAR_POINTER(item2,pl)
VAR(size_t,count)
