file_init(p->f1, file_name1, FILE_FLAG_READ);
file_init(p->f2, file_name2, FILE_FLAG_READ);

