p->p = v;
p->type = type;
p->next = NULL;
p->prev = NULL;
p->l = NULL;
is_init = 1;

