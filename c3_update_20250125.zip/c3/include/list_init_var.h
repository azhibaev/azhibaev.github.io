PARAMETER_POINTER(list_item,parent)
