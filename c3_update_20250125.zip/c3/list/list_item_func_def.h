typedef int (*FUNC(cmp))(T*, T*);
