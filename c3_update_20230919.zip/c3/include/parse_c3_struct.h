VAR_POINTER_INIT(chars,s)
VAR_POINTER_INIT(chars,s_identifier)
VAR_POINTER_INIT(chars,s_string_constant)
