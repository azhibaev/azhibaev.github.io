VAR_POINTER(unsigned char,p)
VAR_POINTER(unsigned int,pa)
VAR(unsigned int,n)
VAR(unsigned int,m)
VAR(unsigned int,i_max)
VAR(unsigned int,n_i)
FLAGS(
FLAG(first)
)
