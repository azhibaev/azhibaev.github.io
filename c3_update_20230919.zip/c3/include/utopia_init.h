int c = 0;
s = chars_init(s, 0);
f = fopen(s, "r");

