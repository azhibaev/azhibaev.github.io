VAR_POINTER(item,p)
VAR_POINTER(item,pf)
VAR_POINTER(item,pl)
VAR(size_t,count)
